#include <iostream>
#include <vector>
#include <map>
#include <exception>
#include <stdexcept>
#include <array>

#include "minqueue.h"

#define CATCH_CONFIG_MAIN
#include "catch.hpp"

using namespace std;

TEST_CASE("Test 01A", "[Project07]")
{
  
  minqueue<char, int> queue(10);
           
  queue.pushinorder('B', 0);
  queue.pushinorder('C', 0);
  queue.pushinorder('D', 0);
  queue.pushinorder('E', 0);
  queue.pushinorder('A', 10);
  queue.pushinorder('Z', 10);
	
  REQUIRE(!queue.empty());

  REQUIRE(queue.minfront() == 'B');
  queue.minpop();
  REQUIRE(queue.minfront() == 'C');
  queue.minpop();
  REQUIRE(queue.minfront() == 'D');
  queue.minpop();
  REQUIRE(queue.minfront() == 'E');
  queue.minpop();
  REQUIRE(queue.minfront() == 'A');
  queue.minpop();
  REQUIRE(queue.minfront() == 'Z');
  queue.minpop();

  REQUIRE(queue.empty());
}

TEST_CASE("Test 01B", "[Project07]")
{
  
  minqueue<char, int> queue(10);
           	
  REQUIRE(queue.empty());
	
}

TEST_CASE("Test 01C", "[Project07]")
{
  
  minqueue<string, char> queue(10);
	
  queue.pushinorder("abc", 'A');
  queue.pushinorder("def", 'A');
  queue.pushinorder("ghi", 'B');
  queue.pushinorder("jkl", 'C');
	
  REQUIRE(queue.minfront() == "abc");
  queue.minpop();
  REQUIRE(queue.minfront() == "def");
  queue.minpop();
  REQUIRE(queue.minfront() == "ghi");
  queue.minpop();
  
  queue.pushinorder("mno", 'C');
  queue.minpop();	
  REQUIRE(queue.minfront() == "mno");
  queue.minpop();
	
  
  
  REQUIRE(queue.empty());
	
}



TEST_CASE("Test 02", "[Project07]")
{
  vector<int>  keys = { 123, 456, 789, 1234, 5678, 91011 };
  char  initialValue = '#';

  minqueue<int, char> queue(keys, initialValue);
           
  REQUIRE(!queue.empty());

  REQUIRE(queue.minfront() == 123);
  queue.minpop();
  REQUIRE(queue.minfront() == 456);
  queue.minpop();
  REQUIRE(queue.minfront() == 789);
  queue.minpop();
  REQUIRE(queue.minfront() == 1234);
  queue.minpop();
  REQUIRE(queue.minfront() == 5678);
  queue.minpop();
  REQUIRE(queue.minfront() == 91011);
  queue.minpop();

  REQUIRE(queue.empty());
}

TEST_CASE("Test 03", "[Project07]")
{
  vector<int>  keys = { 123, 456, 789, 1234, 5678, 91011 };
  string  initialValue = "Hello";

  minqueue<int, string> queue(keys, initialValue);
           
  REQUIRE(!queue.empty());

  REQUIRE(queue.minfront() == 123);
  queue.minpop();
  REQUIRE(queue.minfront() == 456);
  queue.minpop();
  REQUIRE(queue.minfront() == 789);
  queue.minpop();
  REQUIRE(queue.minfront() == 1234);
  queue.minpop();
  REQUIRE(queue.minfront() == 5678);
  queue.minpop();
  REQUIRE(queue.minfront() == 91011);
  queue.minpop();

  REQUIRE(queue.empty());
}

TEST_CASE("Test 04", "[Project07]")
{
  vector<string>  keys = { "abc", "def", "ghi", "jkl", "mno", "pqr" };
  char  initialValue = '#';

  minqueue<string, char> queue(keys, initialValue);
           
  REQUIRE(!queue.empty());

  REQUIRE(queue.minfront() == "abc");
  queue.minpop();
  REQUIRE(queue.minfront() == "def");
  queue.minpop();
  REQUIRE(queue.minfront() == "ghi");
  queue.minpop();
  REQUIRE(queue.minfront() == "jkl");
  queue.minpop();
  REQUIRE(queue.minfront() == "mno");
  queue.minpop();
  REQUIRE(queue.minfront() == "pqr");
  queue.minpop();

  REQUIRE(queue.empty());
}

TEST_CASE("Test 05", "[Project07]")
{
  vector<string>  keys = { "abc", "def", "ghi", "jkl", "mno", "pqr" };
  char  initialValue = '#';

  minqueue<string, char> queue(keys, initialValue);
  
  queue.pushinorder("def", '!');	
	
  REQUIRE(!queue.empty());

  REQUIRE(queue.minfront() == "def");
  queue.minpop();
  REQUIRE(queue.minfront() == "abc");
  queue.minpop();
  REQUIRE(queue.minfront() == "ghi");
  queue.minpop();
  REQUIRE(queue.minfront() == "jkl");
  queue.minpop();
  REQUIRE(queue.minfront() == "mno");
  queue.minpop();
  REQUIRE(queue.minfront() == "pqr");
  queue.minpop();

  REQUIRE(queue.empty());
}

TEST_CASE("Test 06", "[Project07]")
{
  vector<string>  keys = { "abc", "def", "ghi", "jkl", "mno", "pqr" };
  char  initialValue = '#';

  minqueue<string, char> queue(keys, initialValue);
  
  queue.pushinorder("def", '!');	
	
  REQUIRE(!queue.empty());

  REQUIRE(queue.minfront() == "def");
  queue.minpop();
  REQUIRE(queue.minfront() == "abc");
  queue.minpop();
  REQUIRE(queue.minfront() == "ghi");
  queue.minpop();
  REQUIRE(queue.minfront() == "jkl");
  queue.minpop();
  REQUIRE(queue.minfront() == "mno");
  queue.minpop();
  REQUIRE(queue.minfront() == "pqr");
  queue.minpop();

  REQUIRE(queue.empty());
}