/*minqueue.h*/


/*
 * John D. McDonald
 * UIC CS 251
 * Project 07: Minqueue
 * 
 */

// Min queue that stores (key, value) pairs using a min-heap 
// implementation.  When pop is called, the key from the 
// (key, value) pair with the smallest value is returned; if 
// two pairs have the same value, the smaller key is returned.
// Push and pop have O(lgN) time complexity.
//
// Original author: Prof. Joe Hummel
// U. of Illinois, Chicago
// CS 251: Fall 2019
// Project #07

#pragma once

#include <iostream>
#include <map>
#include <vector>
#include <exception>
#include <stdexcept>
#include <array>

using namespace std;


template<typename TKey, typename TValue>
class minqueue
{
private:
  
  // Create a Struct to Store Key / Value Pairs
  struct NODE {
	TKey    Key;
    TValue  Value;
  };
  
  // Create a First Array of Structs to Serve as Minqueue
  NODE* firstArray;

  // Keep Track of the Size of the Active Elements of the Array
  int Size;  
  
  // Keep Track of the Maximum Elements in Array
  int Capacity;

  // Create a Map to Store Key / Position
  // in First Array
  map <TKey, int> posMap;
  
  // Get Left Child's Position: 
  // Get's the Index Position of Left Child
  int getLeftChildIndex(int nodeIndex) 
  {
     return 2 * nodeIndex + 1;
  }
  
  // Get Right Child's Position:
  // Get's the Index Position of Right Child
  int getRightChildIndex(int nodeIndex) 
  {
     return 2 * nodeIndex + 2;
  }
  
  // Get Parent's Position:
  int getParentIndex (int nodeIndex) 
  {
      return (nodeIndex - 1) / 2;
  }
  
  //_siftUp 
  // This is a Helper Function
  // that Other Functions Call Whenever We
  // Have to Sift a Node "UP" From the End of FirstArray
  int _siftUp (int pos) 
  {
  
  	  /* Debug Only
  	  cout << endl;
	  cout << "Before Sift Up: " << endl;
	  
	  for (int i = 0; i < Size; ++i) {
	    
		  cout << firstArray[i].Key << " " << firstArray[i].Value << endl;
	  
	  }
  
      cout << endl;
	  
	  End of Debug */
  
	  int parentPos;
	  NODE tempCurNode;
	  NODE tempParentNode;
	  
	  parentPos = getParentIndex(pos);
	  
	  if (pos != 0) {
	  
		  bool swapCondition;
		  swapCondition = false;
		  
		  if (firstArray[parentPos].Value > firstArray[pos].Value) {
		  
			  swapCondition = true;
		  
		  }
		  
		  if (firstArray[parentPos].Value == firstArray[pos].Value){
			  
			  if (firstArray[parentPos].Key > firstArray[pos].Key) {
		  
				  swapCondition = true;
		  
			  } // End if Parent Key > Child Key Condition
			  
		  } // End if Parent Value Equal Child Value Condition
	  
		  if (swapCondition) {
		  
			  // Assign Nodes
			  tempCurNode = firstArray[pos];
			  tempParentNode = firstArray[parentPos];

			  // Update Second Data Structure			  
			  posMap[tempCurNode.Key] = parentPos;			  
			  posMap[tempParentNode.Key] = pos;
		  
			  // Swap Nodes in First Data Structure		  
			  firstArray[pos] = tempParentNode;
			  firstArray[parentPos] = tempCurNode;
		  
			  /* Debug Only
			  cout << endl;
			  cout << "After Sift Up: " << endl;
	  
			  for (int i = 0; i < Size; ++i) {
	    
				  cout << firstArray[i].Key << " " << firstArray[i].Value << endl;
	  
			  }
  
			  cout << endl;
	  
			  End of Debug */
		  
			// Call Function Recursively
			_siftUp(parentPos);
			
		  } // End of If Swap Condition Met
		 
	  }// End of if Pos != 0 Condition 
	  
	  return pos;
  } // End Sift Up Function
  
  // _siftDown
  // This is a Helper Function Called by 
  // Other Functions Whenever We need to Sift a Node Down
  // From Top of firstArray to Lower Position
  int _siftDown (int pos) 
  {
  
	  /* Debug Only
	  cout << endl;
	  cout << "Before Sift Down: " << endl;
	  
	  for (int i = 0; i < Size; ++i) {
	    
		  cout << firstArray[i].Key << " " << firstArray[i].Value << endl;
	  
	  }
  
      cout << endl;
	  cout << "Check Positions: " << endl;
	  std::map<char, int>::iterator it9;
	  for (int i = 0; i < Size; ++ i) {
	  
		  it9 = posMap.find(firstArray[i].Key);
		  
		  cout << "Key : " << firstArray[i].Key << " " << "pos: " << it9->second << endl;
	  
	  }
	  
	  End of Debug */
  
	  int leftChildPos, rightChildPos, minPos;
	  NODE tempCurNode;
	  NODE tempSmallChild;
	  
	  // Step One: Find Smallest Child
	  leftChildPos = getLeftChildIndex(pos);
	  rightChildPos = getRightChildIndex(pos);
	  
	  if(rightChildPos >= Size) 
	  {
		  if (leftChildPos >= Size) {
			  return pos;
		  } else {
			  minPos = leftChildPos;
		  }
	  } else {
	  
		   // Check if Left Value < Right Value 
		   if (firstArray[leftChildPos].Value < firstArray[rightChildPos].Value) {
			  minPos = leftChildPos;
		   } 
		   
		   // Check if Right Value < Left Value
		   if (firstArray[rightChildPos].Value < firstArray[leftChildPos].Value) {
			   
			   minPos = rightChildPos;
		   
		   }
		   
		   // Check if Left Value == Right Value
		   if (firstArray[leftChildPos].Value == firstArray[rightChildPos].Value) {
		   
			  TKey leftKey;
			  TKey rightKey;
			  
			  leftKey = firstArray[leftChildPos].Key;
			  rightKey = firstArray[rightChildPos].Key;
			  
			  // Check if Left Key < Right Key
			  if (leftKey < rightKey) {
			  
				minPos = leftChildPos;
			  
			  } // End if Left Key < Right Key Check
		   
		      if (rightKey < leftKey) {

				minPos = rightChildPos;
		   
		      } // End if Right Key < Left Key Check
			  
		  } // End "if Values are Equal" Check
		  
	  }  // End Step One
  
	   // Step Two: Determine if Swap Required
	   // If So, Swap and then Call the Function Recursively
	   bool swapCondition;
	   swapCondition = false;
	   
	   if (firstArray[pos].Value > firstArray[minPos].Value) {
	   
		   swapCondition = true;
	   
	   }
	   
	   if (firstArray[pos].Value == firstArray[minPos].Value) {
	   
		   if (firstArray[pos].Key > firstArray[minPos].Key) {
	   
			   swapCondition = true;
	   
		   }
		} 
	   
	   if (swapCondition) 
	   {
	   
			// Assign Temporary Nodes
			tempCurNode = firstArray[pos];
			tempSmallChild = firstArray[minPos];
			
			// Update Map Data Structure to Reflect Position Movement					
			posMap[tempCurNode.Key] = minPos;
			posMap[tempSmallChild.Key] = pos;
					
			// Now Swap the Nodes in the First Data Structure
			firstArray[pos] = tempSmallChild;
			firstArray[minPos] = tempCurNode;
			
			/* Debug Only
			cout << endl;
		    cout << "After Sift Down: " << endl;
	  
			for (int i = 0; i < Size; ++i) {
	    
			  cout << firstArray[i].Key << " " << firstArray[i].Value << endl;
	  
			 }
  
			cout << endl;
	  
		    End of Debug */ 
			
			// Call Function Recursively
			_siftDown(minPos);
			
	   } // End of If Swap Condition 
	   
	  return pos;
  }
  
  // _Delete
  // This is a Helper Function That 
  // the pushinorder Function Calls in the Event
  // that the User is Trying to Push a Key Value Pair 
  // into the Array and It Already Exists in the Array   
  void _Delete (TKey key, TValue value) 
  {
      // Find the Position of the Key
      // in the First Array
	  int pos; 
	  pos = posMap[key];
	  
	  // Option One: 
	  // If Pos is Last Position in Array
	  // Delete Last Position and Return
	  // NOTE: The firstArray Data Structure will be Reduced via Size Variable
	  // NOTE: The posMap Data Structure will Actually be Reduced
	  int endOfArray;
	  endOfArray = Size - 1; // If there are 5 Elements in firstArray, the index of last element is 4
      
	  if (pos == endOfArray) 
	  {
		  Size = Size - 1;
		  posMap.erase(key);
		  
		  /* Debug Size Only
		  if (Size != posMap.size()) {
			  cout << "Error Size Mismatch _Delete Option One" << endl;
		  }
		  End Debug*/
		  
		  return;
	  }
	  
	  // Option Two:
	  // Part A
	  // We Know Pos != endOfMap
	  // So Move Last Key/Value Pair into Current Position
	  // Reduce the Number of Elements by One 
	  
	  NODE tempEndNode;
	  
	  tempEndNode = firstArray[endOfArray]; // tempEndNode stores the Last Node in Array
	  
	  firstArray[pos] = tempEndNode; // Moves the TempEndNode into the Position in the Current Array
	  posMap[tempEndNode.Key] = pos; // Updates the Position Associated with the Key that Used to be at the End of the Array

	  Size = Size - 1; // Reduces the Size of firstArray by One
	  posMap.erase(key); // Reduces the Size of Map by One
	  
	  /*Debug Size Only
	  if (Size != posMap.size()) {
		  cout << "Error Size Mismatch _Delete Option Two" << endl;
	  }
	  End Debug*/
	  
      /*Debug Only
	  cout << endl;
	  cout << "After Delete and Before Sift Up and Down: " << endl;
	  
	  for (int i = 0; i < Size; ++i) {
	    
		cout << firstArray[i].Key << " " << firstArray[i].Value << endl;
	  
	   }
  
	  cout << endl;
	  
	  cout << "Check Positions: " << endl;
	  
	  for (int i = 0; i < Size; ++ i) {
	  
		  it = posMap.find(firstArray[i].Key);
		  
		  cout << "Key : " << firstArray[i].Key << " " << "pos: " << it->second << endl;
	  
	  }
	  
	  End of Debug */ 
	  
	  // Part B:
	  // Let (K, V) be the pair at Pos
	  // K, V is Stored in TempEndNode
	  // The Position of K,V is Stored at Pos
	  // _siftUp Checks Whether a Parent Exists So No Need to Do
	  // So Here  
	  
	  if (pos < 0) {
		  cout << "There is an error, pos < 0.";
		  return;
	  }
	  
	  pos = _siftUp(pos);
	  
	  // Part C:
	  // Check Out Each Child and Percolate if Required
	  // to Ensure firstArray is Still a Heap
	  // NOTE: pos may or may not have been updated at this point
	  // NOTE: if _siftUp was called, then pos was updated to new position
	  // NOTE: if _siftUp was not Called, then pos is the same as it was before Part B
	  // The _siftDown algorithm finds the Smallest Child so No Need to Do So Here  

	  pos = _siftDown(pos);
	  
	  return;
	  
  } // End of _Delete Helper Function

public:
  
  // default constructor:
  //
  // Queue has a max capacity for efficient implementation.
  // This max capacity must be specified at queue creation.
  minqueue(int capacity)
  {
  
	Capacity = capacity;  // This is Fixed Now and Won't Change

	Size = 0; // This Will Change As Items Removed from Queue

	firstArray = new NODE [capacity];
	
  }
  
  // fill constructor:
  //
  // This allows for the efficient O(N) construction of
  // a queue with an initial set of keys, all with the same
  // initial value.  The max capacity of the queue is 
  // set to the # of keys provided for initialization;
  // it is assumed the keys are in ascending order.
  minqueue(vector<TKey> keys, TValue initialValue)
  {
    // Step One: Create firstArray Dynamically
    
	Capacity = keys.size();  // This is Fixed Now and Won't Change

	Size = Capacity; // This WILL Change As Items Removed from Queue

	firstArray = new NODE [Capacity];
	
	// Step Two: Create the Map
	// No Need to Create Map Separately, as It is Created in Private
	// and can Expand and Contract just like Vector
	
	// Step Three: Fill in the firstArray and the Map
	int i;
	for (i = 0; i < keys.size(); ++i) 
	{
	    // Fill the First Array with the Key + the Distance
		firstArray[i].Key = keys[i];
		firstArray[i].Value = initialValue;	
		// Fill the with the Key + the Key's Position in First Array
		posMap[keys[i]] = posMap[keys[i]] + i;
	} // End of For Loop
  } // End of Fill Constructor
  
  // destructor:
  // My Understanding is that We Do Not Need to
  // Free Any Memory Associated with a Map because
  // C++ Tutorials Point Says that a Map Disappears Automatically
  virtual ~minqueue()
  {
   	delete []firstArray;
	Size = 0;
  }
 
  // empty:
  // Returns true if empty, false if not.
  bool empty()
  {
    
	if (Size == 0) {
	
		return true;
	
	}
	
    return false;
  }

  // push:
  //
  // Inserts the given (key, value) pair into the queue such that 
  // pop always returns the pair with the minimum value.  
  // 
  // If the key is *already* in the queue, it's value is updated to the
  // given value and the queue reordered.  
  // 
  // If the key is not in the queue, the (key, value) pairs is added and the queue
  // reordered.
  //
  // NOTE: if two keys have the same value, i.e. (key1, value) and
  // (key2, value), then those pairs are ordered into ascending value
  // by their key.
  void pushinorder(TKey key, TValue value)
  {
    
    /* Debug Only
	cout << endl;
	
	cout << "Vertex Being Pushed: " << key << endl;
	
	cout << "Push In Order Before Delete: " << endl;
	  
	for (int i = 0; i < Size; ++i) {
	    
		cout << firstArray[i].Key << " " << firstArray[i].Value << endl;
	  
	}
  
    cout << endl;
	  
	End of Debug */
	
	
	// Step One:
	// Determine if Key / Value Pair is in the Array
	// If it is in the Array, then use Delete Helper Function on firstArray
	if (posMap.count(key) > 0) {
	
	  _Delete(key, value);
	
	}
	
	/* Debug Only
	cout << endl;
	cout << "Push In Order After Delete: " << endl;
	  
	for (int i = 0; i < Size; ++i) {
	    
		  cout << firstArray[i].Key << " " << firstArray[i].Value << endl;
	  
	 }
  
    cout << endl;
	  
	End of Debug */	
	
	// Step Two:
    // we need to insert a new (key, value) pair but the queue is full:
    // so throw an exception
    // NOTE: AS Per Piazza Post, We Don't have to 'Catch' This Exception
    if (Size == Capacity)
    {
      throw runtime_error("minqueue::pushinorder: queue full");
    }
	
	// Step Three: Use Traditional Push Algorithm
	// Part A: Increase Size of firstArray
    Size = Size + 1; // Increases Size of firstArray
	int endOfArray = Size - 1;
	firstArray[endOfArray].Key = key; // Adds the Key Value Pair to firstArray
	firstArray[endOfArray].Value = value;
	
	// Part B: Add to Map
	posMap[key] = posMap[key] + endOfArray; // map size automatically adjusted

	//Debug Size Only
	if (Size != posMap.size()) {
		cout << "Error Size Mismatch After Insert" << endl;
	}
	//

	// Part C: Swap Nodes As Needed
	_siftUp(endOfArray);

	return;
  }

  // front:
  // Returns the key at the front of the queue; does *not* pop the 
  // (key, value) pair.  Throws a logic_error exception if the queue
  // is empty.
  TKey minfront()
  {
    
	// As Per Piazza
	// We Do Not Need Code to 'Catch' This Error
	if (empty())
    {
      throw logic_error("minqueue::minfront: queue empty");
    }
    
    // Return First Position in Array 
    return firstArray[0].Key;
		
  }

  // pop:
  // Pops and discards the (key, value) pair at the front of the queue.
  // Throws a logic_error exception if the queue is empty.
  void minpop()
  {
    if (empty())
    {
      throw logic_error("minqueue::minpop: queue empty");
    }

	/* Debug Only
	cout << endl;
	cout << "First Array Just Before Pop: " << endl;
	  
	for (int i = 0; i < Size; ++i) {
	    
		  cout << firstArray[i].Key << " " << firstArray[i].Value << endl;
	  
	 }
  
    cout << endl;
	End of Debug */

	int endOfArray;
	endOfArray = Size - 1;

	// Update Map To Reflect the Facts that
	// (i)  First Element of Array is Gone
	// (ii) Last Element of Array's New Position is 0
	posMap[firstArray[endOfArray].Key] = 0;
	posMap.erase(firstArray[0].Key);

    // Move Last Element of Array to Beginning of Array
	firstArray[0] = firstArray[endOfArray];
	
	Size = Size - 1;
	
	/* Debug Size Only
	if (Size != posMap.size()) {
		cout << "Error Size Mismatch After Minpop " << Size << " " << posMap.size() << endl; 
	}
	End Debug */	
		
	if (Size > 0) {
	
		_siftDown(0);
	
	} 
	
	/* Debug Only
	
	cout << "MinPop Size After Pop:" << Size << endl;
	 
	End of Debug */ 
	
  } // End of minpop

}; // End of Program