/*
 * 
 * Project 07: Minqueue
 * UIC CS 251
 * Author: John D. McDonald
 * 
 */

#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <math.h>
#include <vector>
#include <queue>
#include <set>
#include <stack>
#include <fstream>

#include "graph.h"
#include "minqueue.h"

using namespace std;

// Build Graph:
// This Function Takes the Filename and the Graph (by Reference)
// Opens the File, Reads it, and Populates the Graph
bool buildGraph(string filename, graph& g)
{
  ifstream file(filename);

  if (!file.good())
  {
    cout << endl;
    cout << "**Error: unable to open input file '" << filename << "'." << endl;
    cout << endl;
    return false;
  }
  
  char inChar;
  
  // Input vertices as single uppercase letters:  A B C ... #
  // use >> operator, since we are not inputting
  // strings that might contain blanks:
  file >> inChar;
  
  while (!file.eof()) {
     
     // We are at the End of Section with Vertices
     if (inChar == '#') {
      break;  
     }
     
     if (!g.isvertex(inChar)) {
      
      g.addvertex(inChar);
        
     }
     
     file >> inChar;
     
  } // End of Insert Vertices
     
  // Now input edges:  Src Dest Weight ... #
  // use >> operator, since we are not inputting
  // strings that might contain blanks:
  file >> inChar;
  
  while (!file.eof()) {
     
   // We have Hit the End of the File
   // So Return
   if(inChar == '#') {
    
    break;  
      
   } // End if
   
   char from;
   char to;
   int  weight;
   
   // Assign File Values to Variables
   from = inChar;
  
   file >> to;
  
   file >> weight;  // Implicit Type Casting Converts Weight from Char to Int
   
   // You Have Values So Insert Edge
   g.addedge(from, to, weight);
   
   file >> inChar;  
  } // End of Insert Weights

  return true;
}

// BFS:
//
// Performs a breadth-first search from the given starting vertex.  
// Returns the vertices in the order they were visited; startV will
// be first.
vector<char> BFS(graph& g, char startV)
{
  vector<char>  visited;
  queue<char>   frontierQueue;
  set<char>     discoveredSet;

  // Additional Variables
  char         currentV;     // the current Vertex We are Visiting
  char         adjV;         // a single adjacent Vertex to the current Vertex
  vector<char> neighbors;    // vertices that are adjacent to currentV
  

  // Step One:
  // Push starting Vector onto Frontier Queue
  frontierQueue.push(startV);
  
  // Step Two:
  // Add startV to Discovered Set
  discoveredSet.insert(startV);
  
  // Step Three:
  // Visit Each Vertex in the Frontier
  // Check it's Adjacent Vertex to Discovered Set
  while (!frontierQueue.empty()) {
     
     currentV = frontierQueue.front();
     visited.push_back(currentV);
     frontierQueue.pop();
      
     // Find All Neighbors
     neighbors = g.neighbors(currentV);
     
     for (unsigned int i = 0; i < neighbors.size(); i++) {
           
      adjV = neighbors.at(i);
      
         if (discoveredSet.find(adjV) == discoveredSet.end())  // then v is not an element of the set:
         {
            frontierQueue.push(adjV);
            discoveredSet.insert(adjV);
         
         } // End if Conditional
   
     } // End Iteration Through Neighbors
  
  } //End of While Loop, Frontier is Now Empty
  
  return visited;
}
	
// DFS:
//
// Performs a depth-first search from the given starting vertex.  
// Returns the vertices in the order they were visited; startV will
// be first.
vector<char> DFS(graph& g, char startV)
{
  vector<char>  visited;
  stack<char>   frontierStack;
  set<char>     visitedSet;
  
  char          adjV;
  
  vector<char>  neighbors;

  frontierStack.push(startV);

  char currentV;
  
  // TODO: main loop of DFS algorithm 

   while (!frontierStack.empty()) {
      currentV = frontierStack.top();
      frontierStack.pop();
      neighbors = g.neighbors(currentV);   
      
      if (visitedSet.find(currentV) == visitedSet.end())  {
         
         //"Visit" currentV
         visited.push_back(currentV);
         //Add currentV to visitedSet
         visitedSet.insert(currentV);
     
         //for each vertex adjV adjacent to currentV Push adjV to stack
         for (unsigned int i = 0; i < neighbors.size(); ++i) {
            
           adjV = neighbors.at(i);
           
           frontierStack.push(adjV);   
            
         } // End of For Loop
         
      } // End of If Conditional
      
   } // End of While Loop

  return visited;
} // End of DFS Search

// Dijkstra's Algorithm:
// The purpose of this algorithm is to find the Shortest
// Path Between the Starting Vertex and Each Other Vertex
void dAlgo (graph &g, char startV, vector <char> &visited, int (&distance)[26], int (&previous)[26]) {
   
   // Declare Variables
   char currentV;
   char adjV;
   int infinity;
   int edgeWeight;  // Stores the Weight Between Current Vertex and a Given Adjacent Vertex
   int alternativePathDistance;
   int index;
   vector <char> activeVertices;
   vector <char> neighbors;
   
   infinity = std::numeric_limits<int> :: max(); // Stores Highest Possible Integer
   activeVertices = g.vertices(); // Stores the Active Vertices, in Order, That We have to Deal With
	
   // Step One: 
   // (A) Set the Distance of Every Vertex (Whether Active or Not) to Infinity
   // (B) Set the Predecessor of Every Vertex (Whether Active or Not) to -1 
   for (int z = 0; z < 26; ++z) {
   
		distance[z] = infinity;
		previous[z] = -1;
   
   } // End For Loop
   
   // Step One (Cont'd):
   // Push The Vertices & Their Associated Distances
   // Into unvisitedQueue Created Using Fill Constructor
   // NOTE: This Differs From Project 06
   minqueue <char, int> unvisitedQueue(activeVertices, infinity);
   
   // Step Two:
   // Set the Distance of the Starting Vertex to Zero in Distance Array & Queue
   // This Overrides Step One but ONLY with Respect to the Starting Vertex
   distance[startV - 'A'] = 0;  
   unvisitedQueue.pushinorder(startV, 0);

   //NOTES:
   //At this point: 
   //All Active Vertices are in Unvisited Queue; 
   //All Have Predecessors of -1; and 
   //All of them Have Distances of Infinity Except the Starting Vertex  
   
   // Step Four: 
   // Iterate Through the Unvisited Queue
   while (!unvisitedQueue.empty()) 
   {
	   // Let currentV equal the Vertex with the Minimum Distance
	   currentV = unvisitedQueue.minfront(); 

	   /* Debug Only
	
	   cout << "Current V is: " << currentV << endl;
	  
	   End Debug */
	   
	   unvisitedQueue.minpop();
	   index = currentV - 'A';
	   if (distance[index] == infinity) {
	     break;
	   }

       // This is Where we 'Visit' the Vertex
       // by Pushing it's Name into Visited Vector
	   visited.push_back(currentV);
	   
	   //Call the Neighbors 'Method' on 'this' Graph
	   //Which is the Graph on Which dAlgo Was Called
	   neighbors = g.neighbors(currentV); 
       
	     // For Each Vertex in the Neighbors
	     // Vector of Vertices
	     // Check Whether Distance is < Alternative Distance
	     for (unsigned int i = 0; i < neighbors.size(); ++i) {
			 adjV = neighbors[i];
			 edgeWeight = g.getweight(currentV, adjV);
			 index = currentV - 'A';
			 alternativePathDistance = distance[index] + edgeWeight;
			 
			 // Compare Distance from StartV
			 // If Shorter Distance Found then Update
			 index = adjV - 'A';
			 if (alternativePathDistance < distance[index]) {
			 
			   index = adjV - 'A';
			   distance[index] = alternativePathDistance;
			   previous[index] = currentV - 'A';
			   unvisitedQueue.pushinorder(adjV, alternativePathDistance);
			   
			 } // End If
			 
		 } // End For Loop
	      
   } // End While

} // End dAlgo Function


